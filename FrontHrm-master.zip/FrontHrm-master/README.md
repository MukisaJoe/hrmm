# FrontHrm
[NotrinosERP](http://notrinos.com/) Payroll & Human Resource Module

[DEMO](http://notrinos.com/fa/index.php)

[Forum Discussion](http://forums.notrinos.com)

![employee](https://notrinos.com/misc/employee.png)

Requirement
-----------
- NotrinosERP 0.1 or newer

Installation
------------
Install and active the module on NotrinosERP Setup -> Install/Activate extensions
